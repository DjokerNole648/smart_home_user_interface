import javax.swing.*;

public class App {
    protected static int ID;

    public App(int ID){
        this.ID = ID;
    }

    public static void main(String[] args)
    {
        App app = new App(1);

        JFrame mainPage = new mainPage("main page");
        mainPage.setVisible(true);
        mainPage.pack();
    }
}
