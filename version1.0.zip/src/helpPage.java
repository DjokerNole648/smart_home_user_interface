import javax.swing.*;

public class helpPage extends JFrame {
    private JTextArea helpText;
    private JPanel helpPage;

    public helpPage(String title) {
        super(title);
        //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);// to avoid closing help page but closing all pages
        this.setContentPane(helpPage);

        helpText.setText("some descriptions about the system");
    }

    public static void main(String[] args)
    {
        JFrame helpPage = new helpPage("help page");
        helpPage.setVisible(true);
        helpPage.pack();
    }
}
