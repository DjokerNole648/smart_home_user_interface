import javax.swing.*;

public class App {
    protected int ID;

    public App(int ID){
        this.ID = ID;
    }

    public static void main(String[] args)
    {
        App app = new App(1);
        
        JFrame mainPage = new mainPage("main page");
        mainPage.setVisible(true);
        mainPage.pack();

        JFrame helpPage = new helpPage("help page");
        helpPage.setVisible(false);
        helpPage.pack();

        JFrame lightDetailsPage = new lightDetailsPage("details page");
        lightDetailsPage.setVisible(false);
        lightDetailsPage.pack();
    }
}
