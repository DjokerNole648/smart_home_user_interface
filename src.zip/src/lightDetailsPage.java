import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class lightDetailsPage extends JFrame{
    private JButton goBackIcon;
    private JLabel deskLight;
    private JLabel lampPicture;
    protected static JToggleButton controlSwitch;
    private JLabel state;
    private JPanel detailsPage;

    public lightDetailsPage(String title) {
        super(title);
        //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);// to avoid closing help page but closing all pages
        this.setContentPane(detailsPage);
        //controlSwitch.setSelected(rootPaneCheckingEnabled);
        state.setText("ON"); //getState();
        //mainPage.lightState.getText();

        controlSwitch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                state.setText(controlSwitch.isSelected() ? "OFF" : "ON");//change according to the DB
                //change light state (maybe in DB??)
            }
        });
        goBackIcon.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }

        public static void main(String[] args)
        {
            JFrame lightDetailsPage = new lightDetailsPage("details page");
            lightDetailsPage.setVisible(true);
            lightDetailsPage.pack();
        }
}
