import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class mainPage extends JFrame{ //1
    private JPanel mainPage;
    private JLabel someonesHome;
    private JLabel lock;
    private JLabel deskLight;
    private JLabel curtains;
    private JLabel lockState;
    protected JLabel lightState;
    private JLabel curtainsState;
    private JButton help;
    private JLabel lockIcon;
    private JToggleButton lockSwitch;
    private JLabel lightIcon;
    protected JToggleButton lightSwitch;
    private JLabel curtainsIcon;
    private JToggleButton curtainsSwitch;
    private JPanel lockPanel;
    private JButton lockInformation;
    private JButton lightInformation;
    private JButton curtainsInformation;

    public mainPage(String title) {
        super(title);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setContentPane(mainPage);                             //2

        //someonesHome.setText("someone" + "'s home"); //getUsername()
        DB db = new DB();
        String response = db.makeGETRequest("https://studev.groept.be/api/a21ib2c04/selectuser" );
        someonesHome.setText(db.getUserName(response) + "'s home");

        //lock.setText("Smart Lock");
        //deskLight.setText("Smart Desk Light");
        //curtains.setText("Smart Curtains");
        lockState.setText("Offline" + " | " + "Living Room");//getState(), getPlace()
        lightState.setText("Offline" + " | " + "Bedroom");//getState(), getPlace()

        curtainsState.setText("Offline" + " | " + "Living Room");//getState(), getPlace() from DB
        //lightSwitch.setSelected(lightIsOn); from DB

        help.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame helpPage = new helpPage("help page");
                helpPage.setVisible(true);
                helpPage.pack();
            }
        });


        lightInformation.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame lightDetailsPage = new lightDetailsPage("details page");
                lightDetailsPage.setVisible(true);
                lightDetailsPage.pack();
            }
        });

        lightSwitch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lightDetailsPage.controlSwitch.doClick();
                //lightDetailsPage.state
                //change light state (maybe in DB??)
            }
        });
    }

    public static void main(String[] args)
    {
        JFrame mainPage = new mainPage("main page");
        mainPage.setVisible(true);
        mainPage.pack();
    }                                                        //3
}