import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import org.json.*;

public class DB {


    public String makeGETRequest(String urlName){
        BufferedReader rd = null;
        StringBuilder sb = null;
        String line = null;
        try {         //THIS CONNECTION HAS POTENTIAL FOR ERRORS
            URL url = new URL(urlName);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();  //open the connection
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));//get the output of GET request (from above)
            sb = new StringBuilder();
            while ((line = rd.readLine()) != null) //take all the data from website to a big string
            {
                sb.append(line + '\n'); //add each line to StringBuilder
            }
            conn.disconnect(); //no more lines, disconnect
            return sb.toString(); //return the big string
        }
        catch (MalformedURLException e){
            e.printStackTrace();
        }
        catch (ProtocolException e){
            e.printStackTrace();
        }
        catch (IOException e){
            e.printStackTrace();
        }
        return "";

    }

    public void parseJSON(String jsonString){
        try {
            JSONArray array = new JSONArray(jsonString);
            for (int i = 0; i < array.length(); i++)
            {
                JSONObject curObject = array.getJSONObject(i);
                System.out.println("The coach for the " + curObject.getString("Date") + " session is " + curObject.getString("Coach"));
            }
        }
        catch (JSONException e){
            e.printStackTrace();
        }
    }

    public String getUserName(String jsonString){
        String userName = null;
        try {
            JSONArray array = new JSONArray(jsonString);
            for (int i = 0; i < array.length(); i++)
            {
                JSONObject curObject = array.getJSONObject(i);
                //System.out.println("The coach for the " + curObject.getString("Date") + " session is " + curObject.getString("Coach"));
                if(curObject.getInt("ID")==2)    //need to change!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!11
                    userName = curObject.getString("NAME");
            }
        }
        catch (JSONException e){
            e.printStackTrace();
        }
        return userName;
    }


    public static void main(String[] args) {
        DB rc = new DB();
        String response = rc.makeGETRequest("https://studev.groept.be/api/a21ib2demo/all" );
        rc.parseJSON(response);
    }
}


